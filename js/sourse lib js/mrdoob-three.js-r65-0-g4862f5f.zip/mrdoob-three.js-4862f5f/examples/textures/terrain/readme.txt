Textures from http://opengameart.org/

http://opengameart.org/content/dark-grass
http://opengameart.org/content/backgrounds-topdown-games

Slightly modified to have more GPU friendly sizes.

Licensed under a Creative Commons Attribution 3.0 Unported License:
http://creativecommons.org/licenses/by/3.0/