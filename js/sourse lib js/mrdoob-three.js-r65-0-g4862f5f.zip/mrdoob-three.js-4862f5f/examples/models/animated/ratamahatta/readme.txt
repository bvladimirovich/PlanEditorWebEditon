Ratamahatta character by Brian Collins
From http://planetquake.gamespy.com/View.php?view=Quake2.Detail&id=368